
import React from "react";
import ReactDOM from "react-dom/client";
import ConsigView from "./ConsigView.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ConsigView />
  </React.StrictMode>
);
