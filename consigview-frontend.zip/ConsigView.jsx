
import { useState } from "react";

export default function ConsigView() {
  const [cpf, setCpf] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);
  const [dados, setDados] = useState(null);

  const handleConsulta = async () => {
    setLoading(true);
    try {
      const response = await fetch("https://backend-consigview.onrender.com/consultar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cpf, senha }),
      });
      const data = await response.json();
      setDados(data);
    } catch (error) {
      alert("Erro ao consultar. Verifique os dados.");
    }
    setLoading(false);
  };

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4">
      <h1 className="text-3xl font-bold text-center mb-4">ConsigView</h1>
      <div className="space-y-2">
        <input placeholder="CPF" value={cpf} onChange={(e) => setCpf(e.target.value)} />
        <input placeholder="Senha gov.br" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} />
        <button onClick={handleConsulta}>{loading ? "Consultando..." : "Consultar"}</button>
      </div>
      {dados && (
        <div className="mt-4 space-y-2">
          <h2>Nome: {dados.nome}</h2>
          <p>Benefício: {dados.beneficio}</p>
          <p>Banco Pagador: {dados.banco}</p>
          <p>Margem Disponível: {dados.margemDisponivel}</p>
          <h3>Contratos:</h3>
          <ul>
            {dados.contratos.map((c, i) => (
              <li key={i}>{c.banco} - {c.parcela} ({c.parcelas}x) - Saldo: {c.saldo}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
